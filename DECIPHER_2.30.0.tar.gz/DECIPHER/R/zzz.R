.onUnload <- function(libpath)
	library.dynam.unload("DECIPHER", libpath)
